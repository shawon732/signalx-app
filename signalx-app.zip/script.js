// Simulate signal changes
const signalElement = document.getElementById("signal");

const signals = ["BUY NOW 🟢", "SELL NOW 🔴", "WAIT ⏳"];
function updateSignal() {
  const randomSignal = signals[Math.floor(Math.random() * signals.length)];
  signalElement.textContent = randomSignal;
}
updateSignal();
setInterval(updateSignal, 60000); // update every 1 minute
